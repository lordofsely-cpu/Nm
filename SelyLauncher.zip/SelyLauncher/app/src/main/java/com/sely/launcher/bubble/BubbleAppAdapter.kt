package com.sely.launcher.bubble

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.AppInfo
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Click-only app list for the floating bubble's expanded panel.
 *
 * Deliberately separate from AppGridAdapter: that adapter's long-press
 * menu opens a PopupMenu anchored to its item view, which assumes a
 * normal activity window. Anchoring a PopupMenu to a view living inside
 * a TYPE_APPLICATION_OVERLAY window is unreliable across OEMs, so
 * rather than ship something that might silently fail to open, the
 * bubble gets this simpler tap-to-launch-only adapter — which is also
 * the right amount of feature for a quick-switch utility (app
 * info/uninstall already live in App Management).
 */
class BubbleAppAdapter(
    private val context: Context,
    private val apps: List<AppInfo>,
    private val onClick: (AppInfo) -> Unit
) : RecyclerView.Adapter<BubbleAppAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val label: TextView = view.findViewById(R.id.appLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = apps.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.label.setTextColor(ThemeManager.textPrimary(context))
        holder.itemView.setOnClickListener { onClick(app) }
    }
}
