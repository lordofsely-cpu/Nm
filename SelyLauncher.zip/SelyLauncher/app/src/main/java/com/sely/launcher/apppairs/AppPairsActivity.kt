package com.sely.launcher.apppairs

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppInfo
import com.sely.launcher.AppRepository
import com.sely.launcher.databinding.ActivityAppPairsBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely App Pairs — see AppPairLauncher's class doc for the honest scope
 * of what "launch" actually does on a given device.
 */
class AppPairsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppPairsBinding
    private var allApps: List<AppInfo> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppPairsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.pairList.layoutManager = LinearLayoutManager(this)
        binding.createPair.setOnClickListener { startCreateFlow() }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        allApps = AppRepository.loadVisibleApps(this)
        render()
    }

    private fun applyTheme() {
        binding.pairsRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.createPair.setTextColor(ThemeManager.accentColor(this))
        binding.scopeNote.setTextColor(ThemeManager.textSecondary(this))
        binding.emptyState.setTextColor(ThemeManager.textSecondary(this))
    }

    private fun render() {
        val pairs = AppPairStore.getAll(this)
        binding.emptyState.visibility = if (pairs.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.pairList.adapter = AppPairAdapter(
            this, pairs,
            onLaunch = { pair -> AppPairLauncher.launch(this, pair) },
            onDelete = { pair -> AppPairStore.remove(this, pair.name); render() }
        )
    }

    /** Two sequential pick-an-app dialogs, then a name prompt — simple and real. */
    private fun startCreateFlow() {
        pickApp("Choose first app") { appA ->
            pickApp("Choose second app") { appB ->
                val input = EditText(this).apply { setText("${appA.label} + ${appB.label}") }
                AlertDialog.Builder(this)
                    .setTitle("Name this pair")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ ->
                        val name = input.text?.toString()?.trim().orEmpty().ifBlank { "${appA.label} + ${appB.label}" }
                        AppPairStore.add(this, AppPair(name, appA.packageName, appA.activityName, appB.packageName, appB.activityName))
                        render()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
    }

    private fun pickApp(title: String, onPicked: (AppInfo) -> Unit) {
        val labels = allApps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, index -> onPicked(allApps[index]) }
            .show()
    }
}
