package com.sely.launcher.controlcenter

import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.databinding.ActivityControlCenterBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Control Center (spec section 3).
 *
 * Every tile is annotated below with its real Android capability tier —
 * this file is the reference implementation of the 🟢/🟡/🔴 rule from
 * the project spec (§48):
 *
 *  🟢 Flashlight — CameraManager.setTorchMode, works with zero extra
 *     permission on virtually all devices, toggles instantly.
 *  🟢 Do Not Disturb — real toggle via NotificationManager, but requires
 *     one-time user grant of Notification Policy Access (Android
 *     requires this for any app, not just launchers).
 *  🟢 Volume — AudioManager.setStreamVolume, no special permission.
 *  🟡 Brightness — requires WRITE_SETTINGS ("Modify system settings"),
 *     which the user must explicitly grant via a system screen; the
 *     slider is disabled until granted, never faked.
 *  🟡 Wi-Fi — since Android 10, third-party apps (including launchers)
 *     cannot silently flip Wi-Fi on/off. The correct, non-deceptive
 *     approach is Settings.Panel.ACTION_WIFI, which shows Android's own
 *     inline quick-toggle panel without leaving the app.
 *  🟡 Bluetooth — enabling can prompt the system dialog
 *     (ACTION_REQUEST_ENABLE); there is no public API to disable it, so
 *     that case opens Bluetooth settings directly.
 *  🔴 Airplane mode — no public toggle API for any non-privileged app;
 *     this tile is honest about that and deep-links to system settings
 *     instead of pretending to switch it.
 */
class ControlCenterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityControlCenterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityControlCenterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val tiles = listOf(
            ControlTile("Wi-Fi", com.sely.launcher.R.drawable.ic_sely_wifi) { openWifiPanel() },
            ControlTile("Bluetooth", com.sely.launcher.R.drawable.ic_sely_bluetooth) { toggleBluetooth() },
            ControlTile("Flashlight", com.sely.launcher.R.drawable.ic_sely_flashlight) { toggleFlashlight() },
            ControlTile("Do Not Disturb", com.sely.launcher.R.drawable.ic_sely_dnd) { toggleDnd() },
            ControlTile("Airplane Mode", com.sely.launcher.R.drawable.ic_sely_airplane) { openAirplaneSettings() },
            ControlTile("Screenshot", com.sely.launcher.R.drawable.ic_sely_camera) {
                // No API lets a launcher trigger a screenshot itself (🔴);
                // this opens the real editor on an existing image instead.
                startActivity(Intent(this, com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java))
            },
            ControlTile("Screen Record", com.sely.launcher.R.drawable.ic_sely_record) {
                startActivity(Intent(this, com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java))
            },
            ControlTile("Network", com.sely.launcher.R.drawable.ic_sely_network) {
                startActivity(Intent(this, com.sely.launcher.network.NetworkCenterActivity::class.java))
            },
            ControlTile("Quick Switch", com.sely.launcher.R.drawable.ic_sely_switch) {
                val target = com.sely.launcher.multitask.LaunchHistoryStore.quickSwitchTarget(this)
                if (target == null) {
                    Toast.makeText(this, "Open at least two apps through Sely first", Toast.LENGTH_SHORT).show()
                } else {
                    val (packageName, activityName) = target
                    val app = com.sely.launcher.AppRepository.resolveApp(this, packageName, activityName)
                    if (app != null) {
                        com.sely.launcher.multitask.LaunchHistoryStore.recordLaunch(this, app.packageName, app.activityName)
                        startActivity(Intent(Intent.ACTION_MAIN).apply {
                            addCategory(Intent.CATEGORY_LAUNCHER)
                            component = android.content.ComponentName(app.packageName, app.activityName)
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        })
                    }
                }
            },
            ControlTile("Device", com.sely.launcher.R.drawable.ic_sely_device) {
                startActivity(Intent(this, com.sely.launcher.dashboard.DeviceDashboardActivity::class.java))
            },
            ControlTile("Recents", com.sely.launcher.R.drawable.ic_sely_recents) {
                startActivity(Intent(this, com.sely.launcher.multitask.MultitaskHubActivity::class.java))
            },
            ControlTile("Settings", com.sely.launcher.R.drawable.ic_sely_settings) {
                startActivity(Intent(this, com.sely.launcher.SettingsActivity::class.java))
            },
            ControlTile("Command Center", com.sely.launcher.R.drawable.ic_sely_command) {
                startActivity(Intent(this, com.sely.launcher.commandcenter.CommandCenterActivity::class.java))
            },
            ControlTile("Clipboard", com.sely.launcher.R.drawable.ic_sely_clipboard) {
                startActivity(Intent(this, com.sely.launcher.clipboard.ClipboardManagerActivity::class.java))
            },
            ControlTile("Files", com.sely.launcher.R.drawable.ic_sely_files) {
                startActivity(Intent(this, com.sely.launcher.filehub.FileHubActivity::class.java))
            },
            ControlTile("QR Scan", com.sely.launcher.R.drawable.ic_sely_qr) {
                startActivity(Intent(this, com.sely.launcher.qrscanner.QrScannerActivity::class.java))
            },
            ControlTile("Game Mode", com.sely.launcher.R.drawable.ic_sely_record) {
                startActivity(Intent(this, com.sely.launcher.gamemode.GameModeActivity::class.java))
            }
        )

        binding.tileGrid.layoutManager = GridLayoutManager(this, 3)
        binding.tileGrid.adapter = ControlTileAdapter(this, tiles)

        setUpVolumeSlider()
        setUpBrightnessSlider()
    }

    override fun onResume() {
        super.onResume()
        ThemeManager.applyGlass(binding.root, 28f)
        binding.brightnessLabel.setTextColor(ThemeManager.textSecondary(this))
        binding.volumeLabel.setTextColor(ThemeManager.textSecondary(this))
        (binding.tileGrid.adapter)?.notifyDataSetChanged()
    }

    // ---- 🟢 Flashlight: real, immediate, no special permission ----
    private var torchOn = false
    private fun toggleFlashlight() {
        val cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
        } catch (e: Exception) {
            Toast.makeText(this, "Flashlight unavailable: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- 🟢 Do Not Disturb: real toggle, gated on a one-time permission ----
    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            Toast.makeText(this, "Grant Sely notification policy access, then tap again", Toast.LENGTH_LONG).show()
            return
        }
        val turningOn = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(
            if (turningOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    // ---- 🟡 Wi-Fi: Android's own inline panel, not a silent flip ----
    private fun openWifiPanel() {
        startActivity(Intent(Settings.Panel.ACTION_WIFI))
    }

    // ---- 🟡 Bluetooth: can request-enable; disabling has no public API ----
    private fun toggleBluetooth() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            Toast.makeText(this, "No Bluetooth adapter on this device", Toast.LENGTH_SHORT).show()
            return
        }
        if (!adapter.isEnabled) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } else {
            // No public disable API on modern Android; hand off honestly.
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
    }

    // ---- 🔴 Airplane mode: no toggle API exists for this app class ----
    private fun openAirplaneSettings() {
        startActivity(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
    }

    // ---- 🟢 Volume: real, immediate ----
    private fun setUpVolumeSlider() {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        binding.volumeSlider.max = max
        binding.volumeSlider.progress = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        binding.volumeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    // ---- 🟡 Brightness: gated on WRITE_SETTINGS, requested inline ----
    private fun setUpBrightnessSlider() {
        binding.brightnessSlider.max = 255
        if (!Settings.System.canWrite(this)) {
            binding.brightnessSlider.isEnabled = false
            binding.brightnessLabel.text = "Brightness (tap slider to grant permission)"
            binding.brightnessSlider.setOnTouchListener { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                startActivity(intent)
                true
            }
            return
        }
        binding.brightnessSlider.progress = Settings.System.getInt(
            contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128
        )
        binding.brightnessSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }
}
