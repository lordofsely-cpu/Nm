package com.sely.launcher.bubble

import android.content.Context

/**
 * Sely Floating Bubble — remembers where the user left the bubble on
 * screen (so it doesn't jump back to a default corner every time) and
 * whether it's currently running, so Settings can show a live status
 * without having to query ActivityManager for running services.
 */
object BubblePrefs {
    private const val PREFS = "sely_bubble"
    private const val KEY_X = "x"
    private const val KEY_Y = "y"
    private const val KEY_RUNNING = "running"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getPosition(context: Context): Pair<Int, Int> {
        val p = prefs(context)
        return p.getInt(KEY_X, 0) to p.getInt(KEY_Y, 300)
    }

    fun savePosition(context: Context, x: Int, y: Int) {
        prefs(context).edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
    }

    fun setRunning(context: Context, running: Boolean) {
        prefs(context).edit().putBoolean(KEY_RUNNING, running).apply()
    }

    fun isRunning(context: Context): Boolean = prefs(context).getBoolean(KEY_RUNNING, false)
}
