package com.sely.launcher.privacy

import androidx.fragment.app.FragmentActivity

/**
 * Shared unlock flow used by Settings and App Management.
 *
 * Tries biometrics first only when the user explicitly turned that on
 * in Privacy Center AND the device currently has biometrics available;
 * any failure, cancel, or hardware error there falls straight through
 * to the PIN prompt rather than silently locking the user out or
 * silently granting access. The PIN is always the ground truth.
 */
object LockGate {
    fun unlock(activity: FragmentActivity, screenName: String, onSuccess: () -> Unit, onCancel: () -> Unit) {
        val pinPrompt = {
            PinPrompt.show(
                activity,
                title = "Enter PIN to open $screenName",
                onSuccess = onSuccess,
                onCancel = onCancel
            )
        }
        if (PrivacyLockStore.biometricEnabled(activity) && BiometricUnlock.isAvailable(activity)) {
            BiometricUnlock.show(
                activity,
                title = "Unlock $screenName",
                onSuccess = onSuccess,
                onFail = { pinPrompt() }
            )
        } else {
            pinPrompt()
        }
    }
}
