package com.sely.launcher.clock

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Real analog clock face — reads actual system time via
 * `Calendar.getInstance()` and redraws once a second while attached to
 * the window (stops ticking in onDetachedFromWindow so it doesn't run
 * or leak when the Home screen isn't visible).
 */
class AnalogClockView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    constructor(context: Context) : this(context, null)

    var accentColor: Int = Color.WHITE
    var faceColor: Int = Color.WHITE

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(tick)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) / 2f * 0.9f

        val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = faceColor; style = Paint.Style.STROKE; strokeWidth = 4f
        }
        canvas.drawCircle(cx, cy, radius, facePaint)

        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR)
        val minute = calendar.get(Calendar.MINUTE)
        val second = calendar.get(Calendar.SECOND)

        drawHand(canvas, cx, cy, radius * 0.5f, ((hour + minute / 60f) / 12f) * 360f, 8f, faceColor)
        drawHand(canvas, cx, cy, radius * 0.75f, (minute / 60f) * 360f, 5f, faceColor)
        drawHand(canvas, cx, cy, radius * 0.85f, (second / 60f) * 360f, 2f, accentColor)
    }

    private fun drawHand(canvas: Canvas, cx: Float, cy: Float, length: Float, angleDegrees: Float, width: Float, color: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; strokeWidth = width; strokeCap = Paint.Cap.ROUND
        }
        val radians = Math.toRadians((angleDegrees - 90).toDouble())
        val endX = cx + length * cos(radians).toFloat()
        val endY = cy + length * sin(radians).toFloat()
        canvas.drawLine(cx, cy, endX, endY, paint)
    }
}
