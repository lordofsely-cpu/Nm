package com.sely.launcher.sharehub

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Single call site the rest of the app uses to share something through
 * Sely's own hub UI instead of `Intent.createChooser` directly — File
 * Hub, Screenshot Studio, and the QR Scanner all route through this now
 * (see ShareHubActivity.EXTRA_* for what it forwards).
 */
object ShareHub {
    fun open(context: Context, mimeType: String, text: String? = null, streamUri: Uri? = null) {
        val intent = Intent(context, ShareHubActivity::class.java).apply {
            putExtra(ShareHubActivity.EXTRA_MIME_TYPE, mimeType)
            text?.let { putExtra(ShareHubActivity.EXTRA_TEXT, it) }
            streamUri?.let { putExtra(ShareHubActivity.EXTRA_STREAM, it) }
        }
        context.startActivity(intent)
    }
}
