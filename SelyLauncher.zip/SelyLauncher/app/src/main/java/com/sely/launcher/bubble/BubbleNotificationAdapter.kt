package com.sely.launcher.bubble

import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.service.notification.StatusBarNotification
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager

/**
 * Quick-reply list for the Floating Bubble's "Replies" tab.
 *
 * 🟢 Real `RemoteInput` direct-reply — the identical mechanism Android
 * Auto, Wear OS, and the notification shade's own inline-reply button
 * use. An app only gets a reply action here if it *built one into the
 * notification itself* (WhatsApp, Messenger, SMS, Telegram, and most
 * chat apps do; many apps, e.g. email, don't). Where no such action
 * exists, this is honest about it — tapping just opens the app via its
 * notification's own content intent, with no fake reply box.
 */
class BubbleNotificationAdapter(
    private val context: Context,
    private val notifications: List<StatusBarNotification>
) : RecyclerView.Adapter<BubbleNotificationAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.notifBubbleIcon)
        val app: TextView = view.findViewById(R.id.notifBubbleApp)
        val title: TextView = view.findViewById(R.id.notifBubbleTitle)
        val text: TextView = view.findViewById(R.id.notifBubbleText)
        val replyRow: View = view.findViewById(R.id.notifBubbleReplyRow)
        val replyInput: EditText = view.findViewById(R.id.notifBubbleReplyInput)
        val send: ImageView = view.findViewById(R.id.notifBubbleSend)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_bubble_notification, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = notifications.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val sbn = notifications[position]
        val extras = sbn.notification.extras
        val pm = context.packageManager

        holder.icon.setImageDrawable(
            try { pm.getApplicationIcon(sbn.packageName) } catch (e: Exception) { null }
        )
        holder.app.text = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) { sbn.packageName }
        holder.title.text = extras.getCharSequence("android.title") ?: ""
        holder.text.text = extras.getCharSequence("android.text") ?: ""

        val textPrimary = ThemeManager.textPrimary(context)
        val textSecondary = ThemeManager.textSecondary(context)
        holder.app.setTextColor(textSecondary)
        holder.title.setTextColor(textPrimary)
        holder.text.setTextColor(textSecondary)

        val replyAction = sbn.notification.actions
            ?.firstOrNull { action -> action.remoteInputs?.isNotEmpty() == true }

        if (replyAction != null) {
            holder.replyRow.visibility = View.VISIBLE
            holder.replyInput.text = null
            val sendReply = {
                val message = holder.replyInput.text?.toString().orEmpty()
                if (message.isNotBlank()) {
                    sendRemoteInputReply(replyAction, message)
                    holder.replyInput.text = null
                    Toast.makeText(context, "Reply sent", Toast.LENGTH_SHORT).show()
                }
            }
            holder.send.setOnClickListener { sendReply() }
            holder.itemView.setOnClickListener(null)
        } else {
            holder.replyRow.visibility = View.GONE
            // No reply action on this notification — honest fallback:
            // tap opens the app via the notification's own tap intent,
            // exactly what tapping it in the real notification shade does.
            holder.itemView.setOnClickListener {
                try {
                    sbn.notification.contentIntent?.send()
                } catch (e: PendingIntent.CanceledException) {
                    Toast.makeText(context, "Can't open this notification", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun sendRemoteInputReply(action: android.app.Notification.Action, message: String) {
        val remoteInputs = action.remoteInputs ?: return
        val intent = Intent()
        val bundle = android.os.Bundle()
        remoteInputs.forEach { bundle.putCharSequence(it.resultKey, message) }
        RemoteInput.addResultsToIntent(remoteInputs, intent, bundle)
        try {
            action.actionIntent.send(context, 0, intent)
        } catch (e: PendingIntent.CanceledException) {
            Toast.makeText(context, "Couldn't send — try opening the app", Toast.LENGTH_SHORT).show()
        }
    }
}
