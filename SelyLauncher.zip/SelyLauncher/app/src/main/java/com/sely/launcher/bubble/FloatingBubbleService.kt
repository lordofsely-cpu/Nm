package com.sely.launcher.bubble

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.theme.ThemeManager
import kotlin.math.abs

/**
 * Sely Floating Bubble — a draggable launcher bubble that stays on top
 * of whatever app you're in, so you can expand it and jump to another
 * app without going back to Home first.
 *
 * 🟢 Built entirely on real, public APIs:
 *  - `WindowManager` + `TYPE_APPLICATION_OVERLAY` to draw the bubble
 *    over other apps (the standard "chat head" mechanism — the same
 *    one Messenger/Facebook popularized). Requires the user to
 *    explicitly grant "Display over other apps" in system settings;
 *    Sely cannot turn this on silently (see SettingsActivity).
 *  - Runs as a foreground service with an ongoing notification
 *    (required by Android for any long-lived background work, and
 *    doubles as an always-visible "Stop" control independent of the
 *    bubble itself).
 *
 * 🟡 Honest scope note: this bubble does NOT know which app is
 * currently in the foreground — no public API gives a regular app that
 * information without an Accessibility Service (a much bigger
 * permission ask, intentionally not added for this feature). What it
 * does do, truthfully, is stay drawn on top of everything, so it's
 * always reachable to tap and switch — which is the actual ask this
 * was built for.
 */
class FloatingBubbleService : Service() {

    companion object {
        const val ACTION_STOP = "com.sely.launcher.bubble.STOP"
        private const val CHANNEL_ID = "sely_bubble"
        private const val NOTIF_ID = 9101
    }

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
        if (bubbleView == null) addBubble()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        BubblePrefs.setRunning(this, true)
    }

    private fun addBubble() {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble, null)
        val icon = view.findViewById<android.widget.ImageView>(R.id.bubbleIcon)
        icon.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(ThemeManager.accentColor(this@FloatingBubbleService))
        }

        val (savedX, savedY) = BubblePrefs.getPosition(this)
        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var dragged = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = bubbleParams.x
                    initialY = bubbleParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 6 || abs(dy) > 6) dragged = true
                    bubbleParams.x = initialX + dx
                    bubbleParams.y = initialY + dy
                    windowManager.updateViewLayout(view, bubbleParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragged) {
                        BubblePrefs.savePosition(this, bubbleParams.x, bubbleParams.y)
                    } else {
                        togglePanel()
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(view, bubbleParams)
        bubbleView = view
    }

    private fun togglePanel() {
        val existing = panelView
        if (existing != null) {
            windowManager.removeView(existing)
            panelView = null
            return
        }
        val panel = LayoutInflater.from(this).inflate(R.layout.overlay_panel, null)
        ThemeManager.applyGlass(panel, 22f)
        panel.findViewById<android.widget.TextView>(R.id.panelTitle)
            .setTextColor(ThemeManager.textPrimary(this))

        val grid = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.panelAppGrid)
        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = BubbleAppAdapter(this, AppRepository.loadVisibleApps(this)) { app ->
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = android.content.ComponentName(app.packageName, app.activityName)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                startActivity(intent)
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "Can't open ${app.label}", android.widget.Toast.LENGTH_SHORT).show()
            }
            togglePanel()
        }

        val notifList = panel.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.panelNotifList)
        notifList.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)

        val tabApps = panel.findViewById<android.widget.TextView>(R.id.tabApps)
        val tabReplies = panel.findViewById<android.widget.TextView>(R.id.tabReplies)
        val accent = ThemeManager.accentColor(this)
        val secondary = ThemeManager.textSecondary(this)

        fun showApps() {
            grid.visibility = View.VISIBLE
            notifList.visibility = View.GONE
            tabApps.setTextColor(accent)
            tabReplies.setTextColor(secondary)
        }

        fun showReplies() {
            if (!com.sely.launcher.notifications.SelyNotificationListenerService.isEnabled(this)) {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                android.widget.Toast.makeText(this, "Grant Sely notification access to see replies here", android.widget.Toast.LENGTH_LONG).show()
                return
            }
            val notifications = com.sely.launcher.notifications.SelyNotificationListenerService.instance
                ?.activeNotifications
                ?.filter { it.notification.flags and android.app.Notification.FLAG_ONGOING_EVENT == 0 }
                ?.sortedByDescending { it.postTime }
                ?: emptyList()
            notifList.adapter = BubbleNotificationAdapter(this, notifications)
            grid.visibility = View.GONE
            notifList.visibility = View.VISIBLE
            tabApps.setTextColor(secondary)
            tabReplies.setTextColor(accent)
        }

        tabApps.setOnClickListener { showApps() }
        tabReplies.setOnClickListener { showReplies() }
        showApps()

        panel.findViewById<View>(R.id.panelClose).setOnClickListener { togglePanel() }

        val panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = bubbleParams.x
            y = (bubbleParams.y - 400).coerceAtLeast(60)
        }
        windowManager.addView(panel, panelParams)
        panelView = panel
    }

    private fun buildNotification(): android.app.Notification {
        val stopIntent = Intent(this, FloatingBubbleService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Sely Quick Switch is running")
            .setContentText("Tap the bubble to switch apps · Tap Stop to turn off")
            .setSmallIcon(R.drawable.ic_sely_switch)
            .addAction(R.drawable.ic_sely_close, "Stop", stopPending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Floating Bubble", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        panelView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
        bubbleView = null
        BubblePrefs.setRunning(this, false)
    }
}
