package com.sely.launcher.clock

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock

/**
 * Sely Clock System — the actual widget placed on Home and previewed in
 * the picker. `applyStyle` rebuilds its child view(s) for the chosen
 * style; digital styles use Android's own auto-updating `TextClock`
 * (real system time, zero manual refresh logic), analog uses the
 * custom-drawn AnalogClockView.
 */
class ClockWidgetView(context: Context, attrs: AttributeSet?) : FrameLayout(context, attrs) {

    constructor(context: Context) : this(context, null)

    fun applyStyle(style: ClockStyle, textColor: Int, accentColor: Int) {
        removeAllViews()
        when (style) {
            ClockStyle.DIGITAL -> addView(timeAndDate("h:mm", 64f, textColor, accentColor))
            ClockStyle.LARGE -> addView(timeAndDate("h:mm", 84f, textColor, accentColor))
            ClockStyle.MINIMAL -> addView(textClock("HH:mm", 20f, textColor, Gravity.START))
            ClockStyle.VERTICAL -> {
                val column = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                }
                column.addView(textClock("h:mm", 40f, textColor, Gravity.CENTER))
                column.addView(textClock("a, EEE MMM d", 14f, textColor, Gravity.CENTER))
                addView(column)
            }
            ClockStyle.ANALOG -> {
                val analog = AnalogClockView(context).apply {
                    this.faceColor = textColor
                    this.accentColor = accentColor
                }
                addView(analog, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
            }
        }
    }

    /** Big glowing time with the real date underneath (updates itself). */
    private fun timeAndDate(timeFormat: String, sizeSp: Float, textColor: Int, glowColor: Int): LinearLayout {
        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL
        column.gravity = Gravity.CENTER
        column.layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        val time = textClock(timeFormat, sizeSp, textColor, Gravity.CENTER)
        time.setShadowLayer(24f, 0f, 0f, glowColor)
        column.addView(time)
        column.addView(textClock("EEE, d MMM yyyy", 14f, textColor, Gravity.CENTER))
        return column
    }

    private fun textClock(format: String, sizeSp: Float, color: Int, gravity: Int): TextClock {
        return TextClock(context).apply {
            format12Hour = format
            format24Hour = format
            textSize = sizeSp
            setTextColor(color)
            this.gravity = gravity
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, gravity)
        }
    }
}
