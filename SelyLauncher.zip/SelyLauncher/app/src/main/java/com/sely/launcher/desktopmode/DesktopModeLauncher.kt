package com.sely.launcher.desktopmode

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.view.Display
import android.widget.Toast

/**
 * Sely Desktop Mode (spec section 31) — entry point from the phone
 * screen. Finds a real connected external display via `DisplayManager`
 * (🟢 public, documented API) and launches `DesktopHomeActivity`
 * directly onto it with `ActivityOptions.setLaunchDisplayId()`.
 *
 * If no external display is connected, this says so rather than
 * simulating a "desktop" on the phone's own screen — that would
 * misrepresent what the feature actually is (an external-display mode).
 */
object DesktopModeLauncher {

    fun findExternalDisplay(context: Context): Display? {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        return displayManager.displays.firstOrNull { it.displayId != Display.DEFAULT_DISPLAY }
    }

    fun launch(context: Context) {
        val display = findExternalDisplay(context)
        if (display == null) {
            Toast.makeText(context, "Connect an external display (HDMI or wireless) to use Desktop Mode", Toast.LENGTH_LONG).show()
            return
        }
        val options = ActivityOptions.makeBasic().apply { launchDisplayId = display.displayId }
        val intent = Intent(context, DesktopHomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent, options.toBundle())
    }
}
