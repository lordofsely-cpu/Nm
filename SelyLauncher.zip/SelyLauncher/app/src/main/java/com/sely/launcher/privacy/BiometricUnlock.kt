package com.sely.launcher.privacy

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Sely Privacy Center — biometric unlock.
 *
 * 🟢 Real, standard `androidx.biometric` API — the same one every
 * banking/password-manager app uses. It reads whatever fingerprint/face
 * credentials the user already enrolled in Android Settings; Sely never
 * sees or stores any biometric data itself (impossible for a regular
 * app — only the device's secure hardware handles that).
 *
 * This is explicitly an alternative, faster way to pass the *same*
 * check as the PIN, never a replacement for it: [show] always offers
 * "Use PIN instead", and PrivacyLockStore.biometricEnabled() can only
 * be true when a PIN is also set, so there's always a fallback that
 * doesn't depend on the device's own biometrics still being enrolled.
 */
object BiometricUnlock {

    fun isAvailable(activity: FragmentActivity): Boolean {
        val manager = BiometricManager.from(activity)
        return manager.canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    /**
     * Shows the system biometric prompt. [onFail] fires both when the
     * user taps "Use PIN instead" and on any hard error (e.g. too many
     * attempts, hardware unavailable) — the caller should fall back to
     * [PinPrompt] in both cases, exactly as if biometrics were off.
     */
    fun show(activity: FragmentActivity, title: String, onSuccess: () -> Unit, onFail: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        var finished = false
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                if (finished) return
                finished = true
                onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (finished) return
                finished = true
                onFail()
            }
            // onAuthenticationFailed (one wrong finger/face read) is
            // intentionally not handled here — the system prompt stays
            // open and lets the user retry on its own.
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Use PIN instead")
            .build()
        prompt.authenticate(info)
    }
}
