package com.sely.launcher.desktopmode

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppRepository
import com.sely.launcher.databinding.ActivityDesktopHomeBinding
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Desktop Mode (spec section 31).
 *
 * 🟢 This activity is launched with `ActivityOptions.setLaunchDisplayId()`
 * targeting a real connected external display (see DesktopModeLauncher) —
 * a genuinely public, documented API (API 26+) for exactly this: putting
 * an activity on a secondary display. Once running there, `display.id`
 * (via `Context.getDisplay()` on API 30+, `windowManager.defaultDisplay`
 * below that) correctly reports that external display's ID, so apps
 * launched from here are explicitly sent to the same display with the
 * same API — they open there, not on the phone screen underneath.
 *
 * 🔴 What this is NOT: a window manager. Each app opened here runs
 * full-screen on the external display, one at a time — there is no
 * public API for a regular app to give itself multiple resizable,
 * draggable windows sharing a display (that's compositor-level,
 * SystemUI/OEM territory). The "taskbar" below is Sely's own list of
 * apps it has launched there this session (DesktopSessionStore) —
 * tapping an entry re-launches/refocuses that app on the display; it is
 * not a live view of actual window state, since no API exposes that to
 * a regular app either.
 */
class DesktopHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDesktopHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDesktopHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appGrid.layoutManager = GridLayoutManager(this, 6)
        binding.taskbar.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
    }

    override fun onResume() {
        super.onResume()
        binding.root.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.desktopLabel.setTextColor(ThemeManager.textSecondary(this))

        val apps = AppRepository.loadVisibleApps(this)
        binding.appGrid.adapter = DesktopAppAdapter(this, apps) { app ->
            DesktopSessionStore.recordOpened(this, app.packageName, app.activityName)
            launchOnThisDisplay(app.packageName, app.activityName)
        }

        val recent = DesktopSessionStore.getOpened(this).mapNotNull { (pkg, act) -> AppRepository.resolveApp(this, pkg, act) }
        binding.taskbar.adapter = DesktopAppAdapter(this, recent) { app ->
            launchOnThisDisplay(app.packageName, app.activityName)
        }
    }

    /** The real mechanism: explicitly target the display this desktop activity is already running on. */
    private fun launchOnThisDisplay(packageName: String, activityName: String) {
        val displayId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display?.displayId ?: return
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.displayId
        }
        val options = ActivityOptions.makeBasic().apply { launchDisplayId = displayId }
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(packageName, activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(intent, options.toBundle())
    }
}
