package com.sely.launcher.gamemode

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.sely.launcher.AppRepository
import com.sely.launcher.R
import com.sely.launcher.controlcenter.ControlTile
import com.sely.launcher.controlcenter.ControlTileAdapter
import com.sely.launcher.dashboard.DeviceStats
import com.sely.launcher.databinding.ActivityGameModeBinding
import com.sely.launcher.network.NetworkStats
import com.sely.launcher.theme.ThemeManager

/**
 * Sely Game Mode (spec section 22) — see GameModeStore's class doc for
 * the two honesty notes this screen is built around (no CPU/GPU claim;
 * manually opened rather than auto-detecting a game launch).
 *
 * Quick Tools reuses the same real DND toggle pattern as Control
 * Center (NotificationManager, gated on the same one-time Notification
 * Policy Access grant) plus direct shortcuts to Screenshot Studio and
 * Screen Recorder — genuinely useful mid-game, nothing invented.
 */
class GameModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameModeBinding
    private var gameSearchQuery = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolGrid.layoutManager = GridLayoutManager(this, 4)
        binding.toolGrid.adapter = ControlTileAdapter(this, buildTools())

        binding.gameList.layoutManager = LinearLayoutManager(this)
        binding.gameSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                gameSearchQuery = s?.toString().orEmpty()
                renderGameList()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        buildStatsRow()
        renderGameList()
    }

    private fun applyTheme() {
        binding.gameModeRoot.setBackgroundColor(ThemeManager.backgroundColor(this))
        binding.screenTitle.setTextColor(ThemeManager.textPrimary(this))
        binding.scopeNote.setTextColor(ThemeManager.textSecondary(this))
        binding.toolsHeader.setTextColor(ThemeManager.textPrimary(this))
        binding.gamesHeader.setTextColor(ThemeManager.textPrimary(this))
        binding.gamesNote.setTextColor(ThemeManager.textSecondary(this))
        binding.gameSearch.setBackgroundColor(ThemeManager.surfaceGlassColor(this))
        binding.gameSearch.setTextColor(ThemeManager.textPrimary(this))
    }

    private fun buildStatsRow() {
        binding.statsRow.removeAllViews()
        val battery = DeviceStats.battery(this)
        val network = NetworkStats.snapshot(this)

        addStat("${battery.percent}%", if (battery.isCharging) "Battery · Charging" else "Battery")
        addStat(network.connectionType, "Network")
    }

    private fun addStat(value: String, label: String) {
        val card = LayoutInflater.from(this).inflate(R.layout.item_stat_card, binding.statsRow, false)
        card.findViewById<TextView>(R.id.statValue).apply {
            text = value
            setTextColor(ThemeManager.accentColor(this@GameModeActivity))
        }
        card.findViewById<TextView>(R.id.statLabel).apply {
            text = label
            setTextColor(ThemeManager.textSecondary(this@GameModeActivity))
        }
        binding.statsRow.addView(card)
    }

    private fun buildTools(): List<ControlTile> = listOf(
        ControlTile("Do Not Disturb", R.drawable.ic_sely_dnd) { toggleDnd() },
        ControlTile("Screenshot", R.drawable.ic_sely_camera) {
            startActivity(Intent(this, com.sely.launcher.screenshotstudio.ScreenshotStudioActivity::class.java))
        },
        ControlTile("Screen Record", R.drawable.ic_sely_record) {
            startActivity(Intent(this, com.sely.launcher.screenrecorder.ScreenRecorderActivity::class.java))
        },
        ControlTile("Brightness", R.drawable.ic_sely_settings) {
            startActivity(Intent(this, com.sely.launcher.controlcenter.ControlCenterActivity::class.java))
        }
    )

    /** Same real toggle + permission gate as Control Center's DND tile. */
    private fun toggleDnd() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            Toast.makeText(this, "Grant Sely notification policy access, then tap again", Toast.LENGTH_LONG).show()
            return
        }
        val turningOn = nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
        nm.setInterruptionFilter(
            if (turningOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
    }

    private fun renderGameList() {
        val apps = AppRepository.loadVisibleApps(this)
            .filter { it.label.contains(gameSearchQuery, ignoreCase = true) }
        binding.gameList.adapter = GameToggleAdapter(this, apps)
    }
}
