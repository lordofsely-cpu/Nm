package com.sely.launcher.apppairs

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Sely App Pairs (spec section 5/29) — "split screen" shortcuts.
 *
 * See AppPairLauncher's class doc for the honest, load-bearing caveat:
 * launching a pair does NOT reliably force split screen on most phones.
 * This store just remembers which two apps belong together; the launch
 * behavior is a separate, clearly-scoped concern.
 */
data class AppPair(
    val name: String,
    val packageA: String,
    val activityA: String,
    val packageB: String,
    val activityB: String
)

object AppPairStore {
    private const val PREFS = "sely_app_pairs"
    private const val KEY_PAIRS = "pairs"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAll(context: Context): List<AppPair> {
        val raw = prefs(context).getString(KEY_PAIRS, "[]") ?: "[]"
        val array = JSONArray(raw)
        val list = mutableListOf<AppPair>()
        for (i in 0 until array.length()) {
            val o = array.getJSONObject(i)
            list.add(AppPair(o.getString("name"), o.getString("pkgA"), o.getString("actA"), o.getString("pkgB"), o.getString("actB")))
        }
        return list
    }

    fun add(context: Context, pair: AppPair) {
        val current = getAll(context).toMutableList()
        current.add(pair)
        save(context, current)
    }

    fun remove(context: Context, name: String) {
        save(context, getAll(context).filterNot { it.name == name })
    }

    private fun save(context: Context, list: List<AppPair>) {
        val array = JSONArray()
        list.forEach { p ->
            array.put(JSONObject().apply {
                put("name", p.name); put("pkgA", p.packageA); put("actA", p.activityA)
                put("pkgB", p.packageB); put("actB", p.activityB)
            })
        }
        prefs(context).edit().putString(KEY_PAIRS, array.toString()).apply()
    }
}
