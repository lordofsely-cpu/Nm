package com.sely.launcher.soundhaptics

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.sely.launcher.databinding.ActivitySoundHapticsBinding
import com.sely.launcher.theme.ThemeManager

class SoundHapticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySoundHapticsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySoundHapticsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.backArrow.setOnClickListener { finish() }

        binding.appSoundsSwitch.isChecked = SoundHapticsManager.appSoundsEnabled(this)
        binding.touchHapticsSwitch.isChecked = SoundHapticsManager.touchHapticsEnabled(this)
        binding.chargingSoundSwitch.isChecked = SoundHapticsManager.chargingSoundEnabled(this)

        binding.appSoundsSwitch.setOnCheckedChangeListener { _, checked ->
            SoundHapticsManager.setAppSoundsEnabled(this, checked)
        }
        binding.touchHapticsSwitch.setOnCheckedChangeListener { _, checked ->
            SoundHapticsManager.setTouchHapticsEnabled(this, checked)
        }
        binding.chargingSoundSwitch.setOnCheckedChangeListener { _, checked ->
            SoundHapticsManager.setChargingSoundEnabled(this, checked)
        }

        binding.systemSoundRow.setOnClickListener {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
    }

    private fun applyTheme() {
        val textPrimary = ThemeManager.textPrimary(this)
        val textSecondary = ThemeManager.textSecondary(this)

        ThemeManager.applyScreenBackground(binding.soundHapticsRoot)
        binding.screenTitle.setTextColor(textPrimary)
        binding.appSoundsLabel.setTextColor(textPrimary)
        binding.touchHapticsLabel.setTextColor(textPrimary)
        binding.chargingSoundLabel.setTextColor(textPrimary)
        binding.lockSoundNote.setTextColor(textSecondary)
        binding.systemSoundRow.setTextColor(textPrimary)
    }
}
