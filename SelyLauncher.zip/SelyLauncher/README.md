# Sely Launcher — Foundation Build

This is a **real, buildable Android launcher skeleton** — open it in Android
Studio, hit Run, and you can select "Sely Launcher" as your device's default
Home app. What's here:

- ✅ Registered as a HOME launcher (`AndroidManifest.xml` category.HOME filter)
- ✅ Live app grid pulled from `PackageManager` (not a mock list)
- ✅ Tap to launch, long-press → App info / Uninstall via official Android
  intents (`ACTION_APPLICATION_DETAILS_SETTINGS`, `ACTION_DELETE` — both
  route through the system's own dialogs, never silent)
- ✅ Dark/neon "Sely" visual language: deep-blue background, glass cards,
  rounded corners, blue/purple accents
- ✅ Modular package structure (`com.sely.launcher.*`) so each numbered
  feature in the full spec becomes its own module/Activity/Fragment

## Update — batch 2

Added since the first build:

- **Sely App Drawer** (`drawer/AppDrawerActivity`) — full alphabetical
  app list with live search-by-name filtering, slide-up/down transition.
- **Sely Control Center** (`controlcenter/ControlCenterActivity`) — real
  toggles for Flashlight and Do Not Disturb, working Volume and
  Brightness sliders (brightness gated on the `WRITE_SETTINGS`
  permission, requested inline), and honest deep-links to system
  settings for Wi-Fi/Bluetooth/Airplane mode where Android gives
  third-party apps no direct toggle API — see the comment block at the
  top of `ControlCenterActivity.kt` for the 🟢/🟡/🔴 reasoning per tile.
- **Gesture wiring** (`gesture/HomeGestureListener`) — swipe up on Home
  opens the App Drawer, swipe down opens Control Center.
- Refactored app-loading into `AppRepository` so Home and Drawer share
  one source of truth instead of duplicating `PackageManager` calls.

## Update — batch 3

- **Sely Notification Center** (`notifications/`) — real
  `NotificationListenerService` reading live notifications (app icon,
  title, text), tap to expand/collapse, ✕ to clear one, "Clear all"
  button — all via the official cancel APIs. Gated on Android's
  mandatory Notification Access permission grant, with an in-app prompt
  linking straight to that system screen.
- Gesture routing refined: swipe down from the very top edge (like a
  status-bar shade) opens Notification Center; swipe down elsewhere
  opens Control Center; swipe up still opens the App Drawer.

## Update — batch 4

- **Sely Smart Sidebar** (`sidebar/SidebarActivity`) — right-edge-swipe
  panel with a Favorites grid (reuses `AppRepository`/`AppGridAdapter`)
  and a Tools row (reuses `ControlTile`/`ControlTileAdapter`): real
  Flashlight toggle, real clipboard preview (`ClipboardManager` — works
  reliably here since Android's Android-10+ focus restriction on
  clipboard reads is satisfied by the sidebar being the focused
  window), and real Files/Contacts shortcuts via system intents. Tap
  the dimmed area outside the panel to dismiss.
- **Edge gesture engine** (`gesture/EdgeGestureListener`) — detects a
  horizontal swipe starting within ~24dp of either screen edge; wired
  so a right-edge swipe opens the Sidebar (left edge is detected but
  intentionally unbound for now — natural fit for a future
  back/quick-switch gesture).

## Update — batch 5

- **Sely Theme Engine** (`theme/`) — `ThemeManager` is a single
  persisted source of truth (accent color + dark/light mode via
  SharedPreferences) that every screen reads from. `ThemeActivity` is
  the picker UI: three real accent swatches (Sely Blue/Neon/Purple, tap
  to apply instantly) and a dark/light `Switch`. Long-press empty space
  on Home opens it — the standard launcher pattern.
- Wired live into every existing screen: Home, App Drawer, Control
  Center, and Sidebar all now pull their background/text/accent colors
  from `ThemeManager` in `onResume()`, so switching theme and returning
  to any of them re-skins immediately. `AppGridAdapter` and
  `ControlTileAdapter` were updated to use the live accent/text colors
  instead of hardcoded ones.
- Extending this to each future module is the same three-line pattern
  (see `ThemeManager`'s class doc) — not new engineering per screen.

## Update — batch 6

- **Sely Battery Center + Device Dashboard** (`dashboard/`) — combined
  into one screen, reachable from Control Center's new "Device" tile.
  All real, official-API values, none invented (per spec §12):
  battery percentage/charging/health/temperature from the sticky
  `ACTION_BATTERY_CHANGED` broadcast, RAM from
  `ActivityManager.MemoryInfo`, storage from `StatFs`, device info from
  `Build`. A Battery Saver row deep-links to the real system screen
  (🟡 — no public API lets a non-privileged app flip it directly, same
  pattern as Control Center's Wi-Fi tile). Theme-aware like every other
  screen.

## Update — batch 7

- **Sely Multitask Hub** (`multitask/`), reachable from Control Center's
  new "Recents" tile. **Scope note, stated up front and shown in the
  UI**: Android gives third-party launchers no API to the real system
  Recents list, so this tracks apps launched *through Sely* instead —
  `LaunchHistoryStore` records every launch that goes through
  `AppGridAdapter` (home grid, dock, drawer, sidebar all already route
  through it). Two real sections: "Recent" (most-recently-opened, tap
  to reopen, ✕ to remove from history) and "Frequently used" (ranked by
  actual launch count). "Remove" only edits Sely's own history — it
  does not and cannot force-stop another app's process, since no public
  API allows that either (🔴, noted in the code).

## Update — batch 8

- **Sely Settings** (`SettingsActivity`, rewritten from the original
  stub) — a real menu, reachable from Control Center's new "Settings"
  tile:
  - **Appearance**: Themes → Theme Engine
  - **Launcher**: App Drawer, Control Center, Notification Center,
    Sidebar, Multitasking, Battery & Device — each opens the real
    screen already built
  - **Privacy & Permissions**: three live-status rows — Notification
    access, Modify system settings (Write Settings), and Default
    launcher — each shows the actual current grant/role state (checked
    fresh in `onResume`, so coming back from the system screen it links
    to updates immediately) and taps through to the real system screen
    to change it
  - **About**: app name + tagline
  - Fully theme-aware like every other screen

## Update — batch 9

- **Sely Search** (`search/`) — universal search, opened by tapping the
  Home search bar (previously that opened the App Drawer; Drawer keeps
  its own simpler filter too). Three real sources, combined live as you
  type: installed apps (label match), Settings shortcuts (13 common
  destinations — Wi-Fi, Bluetooth, Battery, Display, Sound, Storage,
  Apps, Location, Airplane mode, Date & time, Security, Accessibility,
  NFC — each a real `Settings.ACTION_*` intent), and contacts via the
  official `CONTENT_FILTER_URI` live-filter query. Contacts only appear
  once `READ_CONTACTS` is granted; an inline banner requests it rather
  than the feature silently returning nothing. No AI, no network — pure
  local filtering, per spec §8. Also linked from Sely Settings.

## Update — batch 10

- **Sely Clipboard Manager** (`clipboard/`), reachable from Control
  Center's "Clipboard" tile, Sely Settings, and by tapping the clip
  preview in the Sidebar. **Scope note, stated up front and in the code
  comments**: since Android 10, only the focused app can read clipboard
  contents — there's no API for a launcher to silently watch clipboard
  changes happening in other apps in the background (real background-
  wide capture needs the app to be an input method or accessibility
  service, a much heavier and more privacy-sensitive feature, deliberately
  not bundled in here). So history grows from clips Sely actually
  observes while it's focused (Sidebar open or Clipboard Manager open),
  via a real `ClipboardManager.OnPrimaryClipChangedListener`. Built:
  persisted history, search, pin/unpin favorites (survive Clear All),
  one-tap copy-back, delete, Clear All.

## Update — batch 11

- **Sely File Hub** (`filehub/`), reachable from Control Center's
  "Files" tile, Sely Settings, and the Sidebar's Files shortcut (which
  previously just opened a bare system picker — now opens the real Hub).
  🟢 Four categories queried live via `MediaStore` — Images, Videos,
  Audio, Downloads — with search, and per-file Open/Share/Delete.
  Delete uses Android's actual scoped-storage flow: a direct
  `ContentResolver.delete()` for files Sely owns, and catching
  `RecoverableSecurityException` to launch the system's own delete-
  confirmation dialog for files it doesn't (the officially sanctioned
  pattern, not a workaround). Permission requests correctly split by
  API level (`READ_MEDIA_IMAGES/VIDEO/AUDIO` on 33+, `READ_EXTERNAL_STORAGE`
  below). 🟡 Documents/APKs/ZIPs/everything else deliberately route
  through the real system file picker (`ACTION_OPEN_DOCUMENT`) instead
  of a fake browse UI — arbitrary file-system access needs
  `MANAGE_EXTERNAL_STORAGE`, a Play-Store-restricted permission that's
  a deliberate scope decision, not something to request quietly. Also
  noted honestly in the code: Downloads visibility for files Sely
  didn't create can vary by OEM on API 33+, since there's no dedicated
  "read all downloads" permission in the modern model.

## Update — batch 12

- **Sely QR/Barcode Center** (`qrscanner/`), reachable from Control
  Center, Sidebar, and Settings. Real, working scanner: CameraX drives
  the live preview, ML Kit's on-device Barcode Scanning model decodes
  each frame (Google's current official library for this — on-device,
  no per-scan network call). Detects a code, pauses scanning, and shows
  Open (for URLs)/Copy/Share/Scan-again — all standard Android actions.
  Requires Google Play services on the device, which almost all real
  Android phones have but is worth naming as a real dependency. Added
  CameraX + ML Kit to `app/build.gradle.kts`.

## Update — batch 17

- **Sely Sound & Haptics** (`soundhaptics/`), reachable from Settings.
  🟢 App-open/panel-open sounds use `AudioManager.playSoundEffect()`
  with Android's own built-in effect tones — no bundled audio files
  needed, and Android silently no-ops them if the user's system "Touch
  sounds" master switch is off. 🟢 Touch/gesture vibration uses
  `Vibrator`/`VibrationEffect` (or `View.performHapticFeedback` for
  direct taps) and is now wired into real interactions: app launches,
  swipe up/down, and the right-edge Sidebar swipe. 🟢 Charging sound
  is driven by a manifest-declared receiver for the real
  `ACTION_POWER_CONNECTED` broadcast — one of the few implicit
  broadcasts Android still allows a manifest receiver for since
  Android 8. 🔴 Lock sound is deliberately absent: reacting to
  screen-lock would need `ACTION_SCREEN_OFF`, which Android explicitly
  excludes from manifest receivers, so the only way to catch it is a
  permanently-running foreground service — a real but heavy trade-off
  for a chime, stated in the Settings UI rather than silently skipped.
  Each toggle is independently switchable, per spec §41.

## Remaining from the original spec (~8 items)

Medium: Automation Engine, Widget Center (real AppWidget hosting),
Backup & Restore, Simple Mode (Guest Space is now built — see Privacy
Center), Developer Labs, Branding/logo asset.

Large: Sely Spaces, Communication Hub, Nearby Device Hub, Adaptive
Interface (tablet/foldable/landscape support across
every screen already built).

Very large, its own project: **Sely Transfer** (Wi-Fi Direct file
sharing, Xender-style) — bigger on its own than everything built so far
combined.

## Update — batch 13

- **Sely Screenshot Studio** (`screenshotstudio/`), reachable from
  Control Center's "Screenshot" tile (previously a dead-end toast — now
  opens the real editor), tapping any image in File Hub, and Settings.
  🔴 Stated up front: no API lets a launcher trigger a screenshot
  itself — that's genuinely restricted on Android (hardware button or
  `MediaProjection`-with-fresh-consent only). So this is a real editor
  for existing images: freehand **Draw** (color strokes), **Text**
  (tap to place, drag to reposition), a **Blur** brush that bakes a real
  box blur directly into the bitmap's pixels (not a fake translucent
  overlay — actually redacts the content, see `BitmapBlur`), drag-to-
  select **Crop**, 90° **Rotate**, **Undo**, and **Save**/**Share**,
  which write a genuinely new file to `Pictures/Sely` via `MediaStore`
  (non-destructive — the original is untouched). Honest, stated
  limitation: rotating or cropping clears in-progress draw/text overlays
  (their coordinates would no longer line up post-transform) — the UI
  warns before either action rather than silently misaligning markup.

## Update — batch 14

- **Sely Screen Recorder** (`screenrecorder/`), reachable from Control
  Center's "Screen Record" tile and Settings. The real, official
  Android pipeline — `MediaProjectionManager` → foreground `Service`
  (`foregroundServiceType="mediaProjection"`) → `MediaRecorder` bound to
  a `VirtualDisplay`, saved via `MediaStore` (`Movies/Sely`) using the
  `IS_PENDING` pattern so the file only appears once recording finishes
  cleanly. Two platform requirements stated plainly rather than worked
  around, because they can't be: (1) Android's own system consent
  dialog appears fresh **every single recording session** — no app can
  remember a prior grant and skip it; (2) a persistent, user-visible
  "Sely is recording · Stop" notification is mandatory for the whole
  recording, by OS design. Optional microphone audio via
  `MediaRecorder.AudioSource.MIC`. Recording history list, tap to open
  in any video player. 🔴 "Show touch indicators" is deliberately
  absent — it needs `WRITE_SECURE_SETTINGS`, a signature-level
  permission no regular app can hold. 🟡 Device/internal audio capture
  (as opposed to mic) is real but substantially more complex — noted as
  the next increment rather than half-built.

## Update — batch 15

- **Sely Network Center** (`network/`), reachable from Control Center
  and Settings. Real connection-type detection via
  `ConnectivityManager`/`NetworkCapabilities` (Wi-Fi vs mobile data vs
  ethernet), carrier name via `TelephonyManager`, Bluetooth paired-device
  list, and airplane-mode status — all read live. 🟡 Wi-Fi SSID display
  correctly gated on `ACCESS_FINE_LOCATION` (a real Android privacy rule
  since SSID can reveal location; shown as "Connected" without the name
  if not granted, never faked). 🔴 Hotspot on/off state has no reliable
  public API on modern Android, so that row is a best-effort deep-link
  to system settings rather than a guess. Deliberately distinct from
  Control Center: this is the "what's actually going on" status screen,
  Control Center is the quick-toggle screen.

## Update — batch 16

- **Sely Quick Switch** (spec section 39) — double-tap empty Home space,
  or use Control Center's new "Quick Switch" tile, to jump straight to
  the previously-used app. 🔴 Stated plainly: third-party launchers have
  no API to ask Android what's currently in the foreground, so this
  can't be a true system-level app-switch key — it works off
  `LaunchHistoryStore` (already built for Multitask Hub) instead, same
  honest scoping. Implementation note: it always targets history's
  second entry, not a toggled flag — since launching an app re-records
  it at index 0, that naturally swaps the top two entries each time, so
  repeated taps genuinely bounce between the last two apps with no
  extra state needed.

## Update — batch 17

- **Sely Wallpaper System** (`wallpaper/`), reachable from Sely Theme's
  new "Change wallpaper" row and Settings. Pick an image, adjust real
  **Blur** and **Dim** sliders — both baked directly into the bitmap's
  pixels (blur reuses the same `BitmapBlur` built for Screenshot Studio,
  tiled across the whole image; dim is a genuine alpha-blended overlay),
  then **Set Home**, **Set Lock**, or **Set Both** — genuinely separate
  Home/Lock-screen wallpapers via `WallpaperManager.setBitmap(..., which)`
  on API 24+, a real API Android added specifically for this. A "Daily
  rotation" section lets the user pick a multi-image set via
  `ACTION_OPEN_DOCUMENT` with persistable URI permissions (so access
  survives reboots), rotated once a day by a real `WorkManager`
  `PeriodicWorkRequest`. Timing honesty note, stated in the UI and code:
  Android enforces a 15-minute WorkManager minimum and Doze can delay
  further, so this is scheduled as a realistic 24h period rather than
  promising exact-time delivery no OS actually guarantees. 🟡
  Deliberately not built: true parallax/motion wallpaper — that needs an
  actual Android Live Wallpaper (`WallpaperService` + `Engine`), a
  distinct, substantial component type of its own rather than a setting
  to flip here.

## Update — batch 18

- **Sely Clock System** (`clock/`), embedded live on the Home screen
  (tap it to open the style picker) and linked from Settings. Five real
  styles: Digital, Large, Minimal, and Vertical all use Android's own
  `TextClock` widget (🟢 auto-updates itself from the real system clock
  — no manual refresh logic, no drift risk), and Analog is a custom
  `Canvas`-drawn face reading real `Calendar` time, ticking once a
  second only while attached to the window (stops cleanly when Home
  isn't visible, so it never leaks or runs in the background). The
  picker shows live, ticking previews of each style — not static
  screenshots — so what's shown is exactly what gets applied. Theme-
  aware: text/accent colors follow the current Theme Engine selection.

## Update — batch 19

- **Sely Performance System** (`performance/`), reachable from Settings.
  Stated plainly, per the spec's own requirement: a launcher has no API
  to touch CPU/GPU clocking or thermal policy (🔴) — nothing here
  pretends otherwise. What IS real and wired in: **Battery** mode turns
  off Sely's own screen-transition animations (App Drawer's slide,
  Sidebar's fade — both now check this before calling
  `overridePendingTransition`) and adds a genuine
  `Constraints.setRequiresCharging(true)` to the wallpaper rotation
  WorkManager job, so rotation only runs while charging. **Balanced**
  and **Performance** leave both alone. A "Battery Saver" row deep-links
  to Android's real system screen for actual power savings, the same
  honest pattern used everywhere else a real toggle doesn't exist for a
  launcher to hold.

## Update — batch 20

- **Sely Command Center** (`commandcenter/`), reachable from Control
  Center's new "Command Center" tile and Settings — the central hub
  the spec describes (section 37). A live stats row (battery %, RAM
  used, network status) reuses `DeviceStats`/`NetworkStats` exactly as
  built for Battery/Device Dashboard and Network Center — no duplicated
  logic — plus a 15-tile navigation grid to every screen built so far,
  reusing `ControlTile`/`ControlTileAdapter` as-is since they were
  already a generic label/icon/action shape. Sely Transfer is
  deliberately absent from the grid: it doesn't exist yet, and a tile
  that opens nothing would be exactly the kind of fake functionality
  this project avoids everywhere else.

## Update — batch 21

- **Sely App Management** (`appmanagement/`), reachable from Settings
  and Command Center's "Manage Apps" tile. Full app list with search,
  each row showing real version name and real APK file size (🟡
  honestly labeled as APK size, not total storage — that needs
  `StorageStatsManager` behind the heavier `PACKAGE_USAGE_STATS`
  permission, not required just to list apps). Per-app menu: Open, App
  info, Favorite/Unfavorite, Hide/Unhide, **Add to Home screen** (🟢 real
  `ShortcutManager.requestPinShortcut`, API 26+ — shows the system's own
  pin-confirmation UI), Uninstall.
- **Hiding is now real and wired through**: `HiddenAppsStore` is a
  genuine launcher-level filter (stated plainly: the app is still
  installed and visible in Android's own Settings — no third-party
  launcher can change that) — Home, App Drawer, and Search all now
  route through a new `AppRepository.loadVisibleApps()` that respects it.
- **Favorites are now real too**: the Sidebar's Favorites grid
  previously just showed "the first 8 apps alphabetically" — it now
  reads `FavoritesStore`, falling back to that only until the user
  actually favorites something.

## Update — batch 22

- **Sely Share Hub** (`sharehub/`) — not opened standalone; it's the
  shared bottom-sheet every "Share" action in the app now routes
  through. 🟢 Real resolution via
  `PackageManager.queryIntentActivities()` against an actual
  `ACTION_SEND` intent carrying the real content — the same query the
  system Sharesheet itself runs — so the grid shows whatever's
  genuinely installed (WhatsApp, Bluetooth, Nearby Share, Gmail,
  Messages, Drive, etc.) rather than a hardcoded, staleness-prone list.
  Tapping a target explicit-launches it directly with the same content.
  File Hub, Screenshot Studio, and the QR Scanner's Share buttons all
  now call `ShareHub.open(...)` instead of a raw `Intent.createChooser`.

## Update — batch 23

- **Sely Game Mode** (`gamemode/`), reachable from Control Center,
  Command Center, and Settings. Two honesty notes it's built around,
  stated in the UI itself: 🔴 no launcher API can boost CPU/GPU speed
  (per spec §22's own requirement), so nothing here claims to; 🟡 the
  spec's "Free Fire → Gaming profile" example implies auto-activating
  when a chosen game opens, which needs either the special
  `PACKAGE_USAGE_STATS` permission or an Accessibility Service to detect
  the foreground app — both real options, deliberately not bundled into
  a launcher's gaming dashboard, so this screen is opened manually
  instead. What IS real: live battery/network stats (reusing
  `DeviceStats`/`NetworkStats`), Quick Tools reusing Control Center's
  exact DND toggle pattern plus direct Screenshot Studio/Screen Recorder
  shortcuts, and a real "tag installed apps as games" list
  (`GameModeStore`) that a future Automation Engine could act on.

## Update — batch 24

- **Sely Modes** (`modes/`), reachable from Control Center, Command
  Center, and Settings. Six real built-in profiles (Normal, Gaming,
  Study, Work, Night, Battery Saver) plus user-created custom ones.
  Stated plainly, per `ModeProfile`'s class doc: each mode controls
  three things this project already has genuine authority over —
  accent color + dark/light (`ThemeManager`), Performance mode
  (`PerformanceModeStore`), and Do Not Disturb (`NotificationManager`,
  same permission-gated toggle used elsewhere) — applied instantly and
  visibly on tap, not just saved as a label. Deliberately excluded:
  per-mode wallpaper/favorites/widget layouts — real Android
  capabilities, but automatically swapping them is a meaningfully bigger
  feature than bundling into the same file. "+ Save current" snapshots
  Sely's live settings into a new named custom profile; custom profiles
  can be deleted, built-ins can't.

## Update — batch 25

- **Sely Privacy Center** (`privacy/`), reachable from Settings and
  Command Center. Live permission status for Camera, Microphone,
  Location, Contacts, Notification access, and Default launcher (tap
  any to open the real system screen to change it), plus honest "Not
  used" rows for Accessibility and overlay permissions — Sely uses
  neither, shown for transparency rather than omitted.
  - **Launcher PIN** (`PrivacyLockStore`): a SHA-256-hashed PIN that
    gates Sely's own Settings and App Management screens — stated
    plainly as a launcher-level lock, not a system one (bypassable via
    another launcher or Android's own Settings app, which no
    third-party app can prevent).
  - **Guest Space** (`GuestModeStore`): a real, working visibility
    filter — while active, Home/Drawer/Search show only apps on a
    user-picked allowlist (`AppRepository`'s existing hidden-apps filter
    now layers this in too). Explicitly labeled 🔴 **not** OS-level
    isolation, exactly as spec §9 requires — setting a PIN closes the
    one hole this app can actually close (reopening Settings to turn it
    back off); nothing stronger is claimed.
  - **Hidden Apps**: a consolidated list of everything hidden via App
    Management, with one-tap Unhide.
  - Deliberately not built: "Layout lock" (there's no home-screen icon
    rearranging yet to lock) and "Private search history" (Sely Search
    has never stored history — nothing to make private that isn't
    already absent).

## Update — batch 26: App Pairs + batch 27: Desktop Mode

Both requested together (real split-screen + OPPO-style Desktop Mode).
Platform honesty stated up front, same as in the code:

- **🔴 No public API lets any app force two arbitrary apps into a
  resizable, draggable split-screen view** — that's SystemUI/Recents
  territory. The only real public lever is
  `Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT`, honored only when the device
  is already in a multi-window-capable context.
- **🟡 External-display Desktop Mode is genuinely real**, via the
  public, documented `ActivityOptions.setLaunchDisplayId()` (API 26+).

**Sely App Pairs** (`apppairs/`), reachable from Settings and Command
Center: save two apps as a pair via a simple two-step picker, "Launch"
opens App A then App B with `FLAG_ACTIVITY_LAUNCH_ADJACENT` set. On
tablets/foldables or an existing multi-window session this produces a
real side-by-side split; on most phones Android will just open them one
after another, which the UI states plainly rather than promising
otherwise. Also tells the user the one thing that *does* reliably work
on a phone — Recents' own long-press → Split screen — since no
third-party launcher can trigger that UI programmatically.

**Sely Desktop Mode** (`desktopmode/`), reachable from Settings,
Command Center, and auto-detected while Home is active (a toast
appears when `DisplayManager` reports a new non-default display — real
API, reliable only while Sely's Home process is alive, which is
normally true for the active default launcher). `DesktopHomeActivity`
runs genuinely on the connected external display; every app it opens is
explicitly sent to that same display via the same real API, so apps
actually appear there, not on the phone screen. Stated plainly: this is
not a window manager — each app opened runs full-screen on the external
display one at a time (no public API gives a regular app multiple
resizable windows sharing a display), and the "taskbar" is Sely's own
record of what it has launched there this session, not a live view of
window state (no API exposes that either). With no external display
connected, it says so rather than faking a desktop on the phone's own
screen.

## Reference: what "not built" means here

Each remaining item in the spec is a real, multi-day feature on its own
— they're intentionally **not stubbed with fake UI**, because the spec
itself (§48) requires distinguishing real functionality from pretend
functionality:

- 🟢 Fully supported by public Android APIs — safe to build as designed
- 🟡 Permission/OEM-dependent — build it, but degrade gracefully per device
- 🔴 System-restricted (secure lock screen, forced split-screen, silent
  install, system status bar/Recents replacement) — no launcher can do
  these; the closest legitimate alternative should be built instead

## Build requirements

Android Studio (Koala+), JDK 17, Android SDK 34. No other setup needed —
this project has no external network dependencies beyond standard Maven/
Google repos.
